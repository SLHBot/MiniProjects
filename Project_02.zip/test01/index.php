<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Meta tags for character set and viewport settings -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <!-- Link to Bootstrap CSS and custom styles -->
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="style.css">
  
  <!-- Title of the web page -->
  <title>Calculator</title>
</head>

<body>
  <!-- Calculator container -->
  <div class="cal-area">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-10">
          <div class="card">
            
            <!-- Calculator header -->
            <div class="row">
              <h1 class="text-center">Simple Calculator</h1>
            </div>

            <!-- Input fields for numbers -->
            <div class="row">
              <input class="col-3" type="number" min="0" id="num1" />
              <h3 class="col-2 text-center" id="chngops">+</h3>
              <input class="col-3" type="number" min="0" id="num2" />
            </div>

            <br />

            <!-- Area for selecting arithmetic operations -->
            <div class="ops-area">
              <span class="operators" id="ops1" onclick="opsn1();">+</span>
              <span class="operators" id="ops2" onclick="opsn2();">-</span>
              <span class="operators" id="ops3" onclick="opsn3();">*</span>
              <span class="operators" id="ops4" onclick="opsn4();">/</span>
            </div>
            
            <!-- Display area for the calculation output -->
            <h3 class="text-center text-danger" id="display">OUTPUT</h3>
            <div class="col-12 text-center">
              <!-- Button to trigger the calculation process -->
              <button class="btn btn-primary col-4 m-4" onclick="cal();">Calculate</button>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Link to the JavaScript file for functionality -->
  <script src="script.js"></script>
</body>

</html>