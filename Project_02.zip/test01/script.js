// Getting references to various elements by their IDs
var ops1 = document.getElementById("ops1");
var ops2 = document.getElementById("ops2");
var ops3 = document.getElementById("ops3");
var ops4 = document.getElementById("ops4");
var chng = document.getElementById("chngops");
var getNum1 = document.getElementById("num1");
var getNum2 = document.getElementById("num2");
var result = document.getElementById("display");

// Function to update the operator when it is clicked
function opsn1() {
  if (chng.innerHTML !== ops1.innerHTML) {
    chng.innerHTML = ops1.innerHTML;
  }
}

function opsn2() {
  if (chng.innerHTML !== ops2.innerHTML) {
    chng.innerHTML = ops2.innerHTML;
  }
}

function opsn3() {
  if (chng.innerHTML !== ops3.innerHTML) {
    chng.innerHTML = ops3.innerHTML;
  }
}

function opsn4() {
  if (chng.innerHTML !== ops4.innerHTML) {
    chng.innerHTML = ops4.innerHTML;
  }
}

// Function to perform calculations and update the result
function cal() {
  // Performing calculations based on selected operator
  var addition = parseInt(getNum1.value) + parseInt(getNum2.value);
  var subtraction = parseInt(getNum1.value) - parseInt(getNum2.value);
  var multiplication = parseInt(getNum1.value) * parseInt(getNum2.value);
  var division = parseInt(getNum1.value) / parseInt(getNum2.value);
  var emptyInput1 = getNum1.value = "";
  var emptyInput2 = getNum2.value = "";
  // Updating the result area based on the selected operator
  if (chng.innerHTML == "+") {
    result.innerHTML = addition;
    emptyInput1;
    emptyInput2;
  }

  if (chng.innerHTML == "-") {
    result.innerHTML = subtraction;
    emptyInput1;
    emptyInput2;
  }

  if (chng.innerHTML == "*") {
    result.innerHTML = multiplication;
    emptyInput1;
    emptyInput2;
  }

  if (chng.innerHTML == "/") {
    result.innerHTML = division;
    emptyInput1;
    emptyInput2;
  }
}
